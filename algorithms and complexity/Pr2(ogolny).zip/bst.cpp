﻿#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
#include <algorithm>
#include <chrono>

using namespace std;

struct node
{
    string key;

    int counter = 0;

    node* left = nullptr;
    node* right = nullptr;
};



node* Add(node*& r, string s)
{
    if (r == nullptr)
    {
        r = new node;
        r->key = s;
        r->left = r->right = nullptr;
        r->counter = 1;
        return r;
    }
    if (s == r->key)
    {
        r->counter++;
        return r;
    }
    if (s > r->key) return Add(r->right, s);
    return Add(r->left, s);
}


void PrintInOrder(node* r)
{
    if (!r) return;
    PrintInOrder(r->left);
    cout << " " << r->key << " " << r->counter << endl;
    PrintInOrder(r->right);
}

int WysokoscDrzewa(node*& r)
{
    if (!r) return 0;
    int left = 1 + WysokoscDrzewa(r->left);
    int right = 1 + WysokoscDrzewa(r->right);
    if (left > right)
        return left;
    return right;
}

int SearchCount(node*& r, string s, int counter)
{
    if (r == nullptr || r->key == s)
    {
        counter++;
        return counter;
    }
    if (r->key > s)
    {
        counter++;
        return SearchCount(r->left, s, counter);
    }
    else
    {
        counter++;
        return SearchCount(r->right, s, counter);
    }
}

void Myk(node* r, int depth = 0)
{
    if (!r) return;
    Myk(r->right, depth + 1);
    for (int i = 0; i < depth; i++) cout << "  ";
    cout << r->key << endl;
    Myk(r->left, depth + 1);
}

int main()
{

    string x;
    node* root = nullptr;
    ifstream inFile;
    string FILE = "6.txt";
    inFile.open(FILE);
    if (!inFile)
    {
        cout << "Unable to open file";
        exit(1);
    }

    int licz = 0;

    auto begin = std::chrono::steady_clock::now();

    while (inFile >> x)
    {
        std::transform(x.begin(), x.end(), x.begin(), ::toupper);
        x.erase(std::remove(x.begin(), x.end(), ','), x.end());
        x.erase(std::remove(x.begin(), x.end(), '.'), x.end());
        x.erase(std::remove(x.begin(), x.end(), '?'), x.end());
        x.erase(std::remove(x.begin(), x.end(), '!'), x.end());
        x.erase(std::remove(x.begin(), x.end(), ' - '), x.end());
        x.erase(std::remove(x.begin(), x.end(), '“'), x.end());
        x.erase(std::remove(x.begin(), x.end(), '”'), x.end());
        x.erase(std::remove(x.begin(), x.end(), '"'), x.end());
        Add(root, x);
        licz++;
    }
    auto end = std::chrono::steady_clock::now();
    auto elapsed_ms = std::chrono::duration_cast<std::chrono::milliseconds>(end - begin);

    inFile.close();


    inFile.open(FILE);
    string* tab=new string[licz];
    for (int i = 0; i < licz; i++)
    {
        inFile >> x;
        std::transform(x.begin(), x.end(), x.begin(), ::toupper);
        x.erase(std::remove(x.begin(), x.end(), ','), x.end());
        x.erase(std::remove(x.begin(), x.end(), '.'), x.end());
        x.erase(std::remove(x.begin(), x.end(), '?'), x.end());
        x.erase(std::remove(x.begin(), x.end(), '!'), x.end());
        x.erase(std::remove(x.begin(), x.end(), ' - '), x.end());
        x.erase(std::remove(x.begin(), x.end(), '“'), x.end());
        x.erase(std::remove(x.begin(), x.end(), '”'), x.end());
        x.erase(std::remove(x.begin(), x.end(), '"'), x.end());
        tab[i] = x;
    }
    cout << endl;

    srand(time(NULL));

    const int N = 100;
    int tab2[N];
    for (int j = 0; j < N; j++)
        tab2[j] = rand() % licz + 1;


    int counter = 0;
    for (int i = 0; i < N; i++)
    {
        if (root != nullptr)
        {
            cout << "Slowo dla znalezenia: " << tab[tab2[i]] << endl;
            cout << "Ilosc krokow dla znalezenia tego slowa: " << SearchCount(root, tab[tab2[i]], counter) << endl;
            cout << endl;
        }
    }
    inFile.close();
    cout << "TIME: " << elapsed_ms.count() << "ms" << endl;
    cout << "Wysokosc drzewa: " << WysokoscDrzewa(root) << endl;
    cout << "Ilosc slow w pliku: " << licz << endl;
    return 0;
}
