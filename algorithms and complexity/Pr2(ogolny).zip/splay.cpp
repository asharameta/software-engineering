﻿#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
#include <algorithm>
#include <chrono>

using namespace std;

struct node
{
    string key;
    int counter=0;
    node* left = nullptr;
    node* right = nullptr;
    node* parent=nullptr;
};

node* root=nullptr;

bool IsRoot(node* r)
{
    if (!r)
    {
        cout << "b1";
        return false;
    }
    return (r->parent == root);
}

char WhichChildIAm(node* r)
{
    if (r == r->parent->left) return 'l';
    return 'r';
}


void Rotate(node* B)
{
    if (!B) return;
    if (IsRoot(B)) return;
    node* A = B->parent;

    if (A->left == B)
    {
        node* Beta = B->right;

        B->parent = A->parent;
        if (A->parent->left == A) A->parent->left = B;
        else A->parent->right = B;

        B->right = A;
        A->parent = B;

        A->left = Beta;
        if (Beta) Beta->parent = A;
    }
    else
    {
        node* Beta = B->left;

        B->parent = A->parent;
        if (A->parent->left == A) A->parent->left = B;
        else A->parent->right = B;

        B->left = A;
        A->parent = B;

        A->right = Beta;
        if (Beta) Beta->parent = A;
    }
}

void Splay(node* r)
{
    if (!r) return;
    while (!IsRoot(r))
    {
        if (IsRoot(r->parent))
        {
            Rotate(r);
            continue;
        }
        if (WhichChildIAm(r) != WhichChildIAm(r->parent))
        {
            Rotate(r);  
            Rotate(r);
            continue;
        }
        Rotate(r->parent);
        Rotate(r);
    }
}

node* Add(node*& r, string s, node* par)
{
    if (r == nullptr)
    {
        r = new node;
        r->key = s;
        r->left = r->right = nullptr;
        r->parent = par;
        r->counter = 1;
        Splay(r);
        return r;
    }
    if (s == r->key)
    {
        r->counter++;
        Splay(r);
        return r;
    }
    if (s > r->key) return Add(r->right, s, r);
    return Add(r->left, s, r);
}

void PrintInOrder(node* r)
{
    if (!r) return;
    PrintInOrder(r->left);
    cout << " " << r->key << " " << r->counter << endl;
    PrintInOrder(r->right);
}

void Myk(node* r, int depth = 0)
{
    if (!r) return;
    Myk(r->right, depth + 1);
    for (int i = 0; i < depth; i++) cout << "  ";
    cout << r->key << endl;
    Myk(r->left, depth + 1);
}

int WysokoscDrzewa(node*& r)
{
    if (!r) return 0;
    int left = 1 + WysokoscDrzewa(r->left);
    int right = 1 + WysokoscDrzewa(r->right);
    if (left > right)
        return left;
    return right;
}

int SearchCount(node*& r, string s, int counter)
{
    if (r == nullptr || r->key == s)
    {
        counter++;
        return counter;
    }
    if (r->key > s)
    {
        counter++;
        return SearchCount(r->left, s, counter);
    }
    else
    {
        counter++;
        return SearchCount(r->right, s, counter);
    }
}

int main()
{
    root = new node;
    string x;
    string FILE = "7.txt";
    auto begin = std::chrono::steady_clock::now();
    ifstream inFile(FILE);

    if (!inFile)
    {
        cout << "Unable to open file";
        exit(1);
    }

    int licz = 0;
    while (inFile >> x)
    {
        std::transform(x.begin(), x.end(), x.begin(), ::toupper);
        x.erase(std::remove(x.begin(), x.end(), ','), x.end());
        x.erase(std::remove(x.begin(), x.end(), '.'), x.end());
        x.erase(std::remove(x.begin(), x.end(), '?'), x.end());
        x.erase(std::remove(x.begin(), x.end(), '!'), x.end());
        x.erase(std::remove(x.begin(), x.end(), ' - '), x.end());
        x.erase(std::remove(x.begin(), x.end(), '“'), x.end());
        x.erase(std::remove(x.begin(), x.end(), '”'), x.end());
        x.erase(std::remove(x.begin(), x.end(), '"'), x.end());
        Add(root->right, x, root);
        licz++;
    }
    inFile.close();
    auto end = std::chrono::steady_clock::now();
    auto elapsed_ms = std::chrono::duration_cast<std::chrono::milliseconds>(end - begin);

    ifstream inFile2(FILE);
    string* tab=new string[licz];
    for (int i = 0; i < licz; i++)
    {
        inFile2 >> x;
        std::transform(x.begin(), x.end(), x.begin(), ::toupper);
        x.erase(std::remove(x.begin(), x.end(), ','), x.end());
        x.erase(std::remove(x.begin(), x.end(), '.'), x.end());
        x.erase(std::remove(x.begin(), x.end(), '?'), x.end());
        x.erase(std::remove(x.begin(), x.end(), '!'), x.end());
        x.erase(std::remove(x.begin(), x.end(), '“'), x.end());
        x.erase(std::remove(x.begin(), x.end(), '”'), x.end());
        x.erase(std::remove(x.begin(), x.end(), ' - '), x.end());
        x.erase(std::remove(x.begin(), x.end(), '"'), x.end());
        tab[i] = x;
    }
    inFile2.close();

    srand(time(NULL));

    int N = 100;
    int* tab2= new int[N];
    for (int j = 0; j < N; j++)
        tab2[j] = rand() % licz + 1;

    cout << endl;
    cout << endl;


    int counter = 0;
    for (int i = 0; i < N; i++)
    {
        if (root != nullptr)
        {
            cout << "Slowo dla znalezenia: " << tab[tab2[i]] << endl;
            cout << "Ilosc krokow dla znalezenia tego slowa("<<i+1<<"): " << SearchCount(root->right, tab[tab2[i]], counter) << endl;
            cout << endl;
        }
    }

    cout << "TIME: " << elapsed_ms.count() << "ms" << endl;
    cout << "Wysokosc drzewa: " << WysokoscDrzewa(root) << endl;
    cout << "Ilosc slow w pliku: " << licz << endl;

    return 0;
}
